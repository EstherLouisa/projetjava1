package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import core.Database;
import entities.Categorie;

public class CategorieRepository  extends Database{
    private final String SQL_INSERT="INSERT INTO `categorie` ( `nomCat_categorie`) VALUES (?";
    private final String SQL_SELECT="select * from categoie";
    

    public void insert(Categorie categorie){
        ouvrirConnexion();
        initPrepareStatement(SQL_INSERT);
        try {
            statement.setString(1, categorie.getNomCat());
    
            executeUpdate();
            fermerConnexion();
        } catch (SQLException e) {
            e.printStackTrace();
        }
     }

  public List<Categorie> select() {
    List<Categorie>categories=new ArrayList<>();
    ouvrirConnexion();
    initPrepareStatement(SQL_SELECT);
    
    ResultSet rs = executeSelect();
      try {
        while (rs.next()) {
             Categorie categorie=new Categorie();
             categorie.setId_categorie(rs.getInt("id_categorie"));
             categorie.setNomCat(rs.getString("nomCat_categorie"));
             
             categories.add(categorie);
          }
        rs.close();
        fermerConnexion();
    } catch (SQLException e) {
        e.printStackTrace();
    }
       return categories;
  }

  
}
