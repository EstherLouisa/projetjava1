package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import core.Database;
import entities.Article;
import entities.Categorie;

public class ArticleRepository extends Database {
    private final String SQL_INSERT="INSERT INTO `article` ( `titre`, `contenu`, `dateCreation`,`etat`, `categorie_id`) VALUES (?,?,?,?,?)";
    private final String SQL_SELECT="SELECT * FROM `article` a, categorie ca WHERE a.categorie_id=ca.id_categorie";
     public void insert(Article article){
       ouvrirConnexion();
        initPrepareStatement(SQL_INSERT);
        try {
            statement.setString(1, article.getTitre());
            statement.setString(2, article.getContenu());
            statement.setString(3, article.getDateCreation());
            statement.setString(4, article.getEtat());
            statement.setInt(4, article.getCategorie().getId_categorie());
            executeUpdate();
            fermerConnexion();
        } catch (SQLException e) {
            e.printStackTrace();
        }
  }

  public List<Article> select(){
       List<Article>articles=new ArrayList<>();
    ouvrirConnexion();
    initPrepareStatement(SQL_SELECT);
    ResultSet rs = executeSelect();
      try {
        while (rs.next()) {
             Categorie categorie=new Categorie();
              categorie.setId_categorie(rs.getInt("id_categorie"));
              categorie.setNomCat(rs.getString("nomCat_categoie"));
            
              Article article=new Article();
              article.setId_article(rs.getInt("article_id"));
              article.setTitre(rs.getString("titre"));
              article.setContenu(rs.getString("contenu"));
              article.setDateCreation(rs.getString("dateCreation"));
              article.setEtat(rs.getString("etat)"));
              article.setCategorie(categorie);
              articles.add(article);
          }
        rs.close();
        fermerConnexion();
    } catch (SQLException e) {
        e.printStackTrace();
    }
       return articles;
  } 
}


