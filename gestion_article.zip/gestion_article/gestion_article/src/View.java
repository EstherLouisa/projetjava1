import java.util.List;
import java.util.Scanner;

import entities.Article;
import entities.Categorie;
import services.ArticleService;
import services.CategorieService;

public class View {
    public static void main(String[] args) throws Exception {
        Scanner scanner=new Scanner(System.in);
        CategorieService categorieService=new CategorieService();
        ArticleService articleService=new ArticleService();
        int choix;
        do{
            System.out.println("1-Creer Categorie");
            System.out.println("2-Lister les  Categories");
            System.out.println("3-Ajouter Article");
            System.out.println("4-Lister les Articles");
            System.out.println("5-Quitter");
           choix=scanner.nextInt();
           scanner.nextLine();
           switch (choix) {
            case 1:
             Categorie categorie=new Categorie();
             System.out.println("Nom ");
             categorie.setNomCat(scanner.nextLine());  
             categorieService.creerCategorie(categorie); 
                break;
             
            case 2:
            List<Categorie> categories = categorieService.listerCategorie();
             for (Categorie ca : categories) {
               System.out.println("Nom :"+ca.getNomCat()); 
        
               System.out.println("------------------------------------");
             }
               break;

               case 3:
               Article article=new Article();
               System.out.println("Entrer le titre");
              article.setTitre(scanner.nextLine());
              System.out.println("Entrer le contenu");
              article.setContenu(scanner.nextLine());
              System.out.println("Entrer le date de creation");
              article.setDateCreation(scanner.nextLine());
              System.out.println("Entrer l'etat'");
              article.setEtat(scanner.nextLine());
                article.setCategorie(categorie);
                articleService.ajouterArticle(article);
              }
              break;
              
              case 4:
              List <Article> articles = articleService.listerArticles();
               for (Article article : articles) {
                System.out.println("Categorie "+article.getCategorie().getNomCat()); 
                System.out.println("Titre"+article.getTitre()); 
                System.out.println("Contenu "+article.getContenu()); 
                System.out.println("Date Creation"+article.getDateCreation());
                System.out.println("Etat"+article.getEtat());
                System.out.println("------------------------------------"); 
               }
    }while(choix!=5);
    scanner.close();
        }

        
}



