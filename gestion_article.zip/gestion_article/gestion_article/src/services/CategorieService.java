package services;

import java.util.List;

import entities.Categorie;
import repositories.CategorieRepository;

public class CategorieService {
    private CategorieRepository categorieRepository=new CategorieRepository();
   public void creerCategorie(Categorie categorie){
     categorieRepository.insert(categorie);
   }

   public List<Categorie> listerCategorie(){
       return categorieRepository.select();
   }
   
}
